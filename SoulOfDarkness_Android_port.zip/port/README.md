# Soul of Darkness — port nativo para Android

O jogo original (Java/J2ME) roda aqui **dentro de um app Android comum**, sem emulador: o código do jogo
(`app/libs/game.jar`, já com o MOD de vida/inimigos em dobro) é convertido para dex e conversa com uma
camada de compatibilidade pequena que traduz as APIs do J2ME para as do Android.

## Como gerar o APK
1. Instale o **Android Studio** (versão recente, JDK 17 já vem junto).
2. `File > Open` e escolha esta pasta. Aguarde o *Gradle sync* (precisa de internet na primeira vez;
   ele baixa o Gradle 8.7, o plugin 8.5.2 e o SDK 34 — aceite as licenças se pedir).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`. Copie para o celular e instale
   (permita "instalar apps desconhecidos"). Para testar direto: ligue o celular por USB e clique em ▶ Run.

## O que tem aqui
| Caminho | Função |
|---|---|
| `app/libs/game.jar` | o jogo (classes + recursos). Troque por outro jar para portar outra versão |
| `javax/microedition/lcdui/*` | Canvas, Graphics, Image, Font, Display... sobre `android.graphics` |
| `javax/microedition/rms/*` | salvamento (RecordStore) em arquivos na pasta interna do app |
| `javax/microedition/media/*` | Player (MIDI/WAV/AMR/MP3) sobre `MediaPlayer` |
| `javax/microedition/midlet/*`, `com/nokia/mid/ui/*` | MIDlet, FullCanvas, DirectGraphics |
| `com/sod/port/MainActivity` | ciclo de vida (start/pause/destroy), teclado físico/gamepad |
| `com/sod/port/GameSurface` | desenha o quadro 240x320 escalado + controles |
| `com/sod/port/Controls` | botões na tela (D-pad, OK, 5/1/3, MENU/VOLTAR, teclado numérico "123") |

## Controles
- **D-pad** (aceita diagonal), **OK** = tecla central (−5), **5 / 1 / 3** = teclas numéricas,
  **MENU / VOLTAR** = softkeys esquerda/direita (−6 / −7), botão **123** abre o teclado numérico completo.
- Teclado/gamepad Bluetooth: setas, Enter, 0–9, `*`, `#`, Menu = softkey esquerda, Voltar = softkey direita.
- Não sei quais teclas fazem o quê no jogo (atacar, pular, magia). Se a ação que você quer não está nos
  botões, abra o teclado "123" e teste; depois ajuste os botões em `Controls.buildButtons()`.

## Se algo der errado
- **Erro do D8 / "class file version 45" no build:** me mande o texto completo do erro.
- **Fecha ao abrir / tela preta:** conecte por USB e veja o Logcat (filtro `SOD` ou `AndroidRuntime`) e me mande.
- **Imagem borrada ou serrilhada demais:** `GameSurface.SMOOTH` (true = suave, false = pixels nítidos).
- **Sem som:** o jogo usa MIDI; alguns aparelhos não tocam MIDI via `MediaPlayer`. Me diga o modelo.
- O Gradle Wrapper (`gradlew`) não está incluso; o Android Studio usa o Gradle indicado em
  `gradle/wrapper/gradle-wrapper.properties`.

## Limitações conhecidas
- Nunca foi executado num Android de verdade por quem escreveu (sem SDK no ambiente de criação): a camada foi
  compilada contra stubs e checada para que **toda** API J2ME usada pelo jogo exista com a assinatura exata,
  mas pode haver diferenças de comportamento (texto, desenho, áudio, desempenho).
- A fonte do texto é a do sistema Android (o jogo usa principalmente fonte própria em sprites).
- O processo é encerrado ao fechar o app (o jogo guarda muito estado em campos `static`).

## Multiplayer: correcao do jogador 2 (teleporte e dano)
- O jogador 2 nao e mais teleportado: fica preso dentro da tela (parede invisivel) e so reaparece junto do
  jogador 1 se cair do mapa ou ficar muito longe (troca de sala).
- `game.jar` agora chama `Hook.pre(inimigo)` / `Hook.post()` em volta da atualizacao de cada inimigo em `e.ak()`
  (feito por `tools/PatchJar.java`, usa o ASM interno do JDK 21). O Hook escolhe como alvo o heroi que esta
  atacando aquele inimigo (ou o mais proximo), entao o jogador 2 passa a dar e receber dano.
- Vida (`e.q`) e invencibilidade temporaria sao estaticos do jogo: a barra de vida e compartilhada pelos dois.
- Nao foi testado em aparelho: se algo falhar, veja o Logcat (filtro `SOD`) e o texto "H2 erro" no canto da tela.

## Remaster HD (4x)
O jogo continua rodando em 240x320 (logica, colisao, multiplayer), mas o quadro agora e desenhado em
**960x1280** (`HdPack.SCALE = 4`) e cada imagem carregada ganha uma versao 4x maior:
- **Automatico, sem fazer nada:** sprites/HUD/imagens pequenas ou com transparencia usam pixel art (EPX x2, sem
  cores novas, bordas nitidas); fundos, tilesets e retratos sem transparencia usam bicubico (`Upscale.java`).
- **Qualidade maxima (opcional):** na primeira execucao o app grava cada PNG que o jogo cria em
  `Android/data/com.sod.port/files/dump/` (jogue todas as fases para pegar tudo; `HdPack.DUMP`).
  No PC: `python tools/upscale_hd.py dump hd --esrgan caminho/realesrgan-ncnn-vulkan` (a IA so e usada nos
  fundos; sprites seguem em pixel art). Copie a pasta `hd/` para `Android/data/com.sod.port/files/hd/`
  (ou para `app/src/main/assets/hd/` e gere o APK de novo). O nome do arquivo e o CRC32 do PNG original.
  Cada variante de paleta que o jogo montar vira uma imagem diferente, entao cada uma e ampliada separadamente.
- Mude o fator em `HdPack.SCALE` (2, 4 ou 8) e use o mesmo `--scale` no script. 8x = 1920x2560 (mais memoria).
- Se faltar memoria numa imagem, ela volta para o original (pixelada) e o log `SOD` avisa; `largeHeap` esta ligado.
- Multiplayer: o convidado continua recebendo o quadro em 240x320 (a rede nao carrega HD).
- Nao testado em aparelho (sem SDK aqui): a camada J2ME + HdPack + Upscale compila contra stubs, e o EPX do Java
  foi conferido pixel a pixel com o do script Python.

## Visual extra (PostFx.java) e fundos limpos
- **Fundos:** antes de ampliar, tira o quadriculado (dithering) com um filtro que preserva as bordas
  (`Upscale.dedither`; o `upscale_hd.py` faz o mesmo antes da IA). O halo da lua vira degradê em vez de pontinhos.
- **PostFx** (por cima do quadro, so visual): correcao de cor (contraste/saturacao/tom quente), **brilho (bloom)**
  nas partes claras, **vinheta** nos cantos e **faiscas** flutuando (cor acompanha a cena). Cada efeito liga/desliga
  nas constantes no topo de `PostFx.java` (`GRADE`, `BLOOM`, `VIGNETTE`, `EMBERS`, ou `ENABLED` para tudo).
  Intensidades: `BLOOM_THRESHOLD/GAIN/ALPHA_*`, `VIGNETTE_STRENGTH`, `EMBER_COUNT`.
- Se o aparelho for lento (bloom gastando >14 ms por quadro), o bloom e as faiscas desligam sozinhos.
- Limite conhecido: a ampliacao suave pode deixar uma emenda fraca na borda de tiles que ficam colados no atlas.
