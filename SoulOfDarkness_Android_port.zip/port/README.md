# Soul of Darkness — port nativo para Android

O jogo original (Java/J2ME) roda aqui **dentro de um app Android comum**, sem emulador: o código do jogo
(`app/libs/game.jar`, já com o MOD de vida/inimigos em dobro) é convertido para dex e conversa com uma
camada de compatibilidade pequena que traduz as APIs do J2ME para as do Android.

## Como gerar o APK
1. Instale o **Android Studio** (versão recente, JDK 17 já vem junto).
2. `File > Open` e escolha esta pasta. Aguarde o *Gradle sync* (precisa de internet na primeira vez;
   ele baixa o Gradle 8.7, o plugin 8.5.2 e o SDK 34 — aceite as licenças se pedir).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`. Copie para o celular e instale
   (permita "instalar apps desconhecidos"). Para testar direto: ligue o celular por USB e clique em ▶ Run.

## O que tem aqui
| Caminho | Função |
|---|---|
| `app/libs/game.jar` | o jogo (classes + recursos). Troque por outro jar para portar outra versão |
| `javax/microedition/lcdui/*` | Canvas, Graphics, Image, Font, Display... sobre `android.graphics` |
| `javax/microedition/rms/*` | salvamento (RecordStore) em arquivos na pasta interna do app |
| `javax/microedition/media/*` | Player (MIDI/WAV/AMR/MP3) sobre `MediaPlayer` |
| `javax/microedition/midlet/*`, `com/nokia/mid/ui/*` | MIDlet, FullCanvas, DirectGraphics |
| `com/sod/port/MainActivity` | ciclo de vida (start/pause/destroy), teclado físico/gamepad |
| `com/sod/port/GameSurface` | desenha o quadro 240x320 escalado + controles |
| `com/sod/port/Controls` | botões na tela (D-pad, OK, 5/1/3, MENU/VOLTAR, teclado numérico "123", botão FIT/FULL) |

## Tela e controles (modo paisagem)
O app abre **sempre deitado** (`sensorLandscape`: funciona nos dois lados) e desenha por baixo do entalhe da câmera.
O jogo é 240x320 (retrato, proporção 3:4), então há dois modos, alternados pelo botão **FIT / FULL** (canto superior esquerdo;
a escolha fica salva):
- **FIT**: o jogo ocupa a altura toda, sem distorcer, no centro; os botões ficam nas faixas pretas laterais (como no PPSSPP).
- **FULL** (padrão): o jogo é esticado para cobrir a tela inteira (fica bem largo/distorcido) e os botões ficam translúcidos por cima.

Disposição: **direcional** embaixo à esquerda (aceita diagonal) · **OK / 5 / 1 / 3** em losango embaixo à direita ·
**MENU** (softkey esquerda) no alto à esquerda · **VOLTAR** (softkey direita) no alto à direita · **123** (alto, à direita) troca
o losango pelo teclado numérico completo (0-9, `*`, `#`).

Teclas que o jogo realmente lê (conferido no código do jogo): setas (e 2/4/6/8 como equivalentes), **OK e 5 são a mesma ação principal**,
**1 e 3** (ações secundárias), 0, `*`, `#`, 9 e as duas softkeys. Para mudar o mapeamento, edite `Controls.buildButtons()`;
para mudar a posição/tamanho, `Controls.layout()` (ramo "paisagem").
- Teclado/gamepad Bluetooth: setas, Enter, 0–9, `*`, `#`, Menu = softkey esquerda, Voltar = softkey direita.

## Se algo der errado
- **Erro do D8 / "class file version 45" no build:** me mande o texto completo do erro.
- **Fecha ao abrir / tela preta:** conecte por USB e veja o Logcat (filtro `SOD` ou `AndroidRuntime`) e me mande.
- **Imagem borrada ou serrilhada demais:** `GameSurface.SMOOTH` (true = suave, false = pixels nítidos).
- **Sem som:** o jogo usa MIDI; alguns aparelhos não tocam MIDI via `MediaPlayer`. Me diga o modelo.
- O Gradle Wrapper (`gradlew`) não está incluso; o Android Studio usa o Gradle indicado em
  `gradle/wrapper/gradle-wrapper.properties`.

## Limitações conhecidas
- Nunca foi executado num Android de verdade por quem escreveu (sem SDK no ambiente de criação): a camada foi
  compilada contra stubs e checada para que **toda** API J2ME usada pelo jogo exista com a assinatura exata,
  mas pode haver diferenças de comportamento (texto, desenho, áudio, desempenho).
- A fonte do texto é a do sistema Android (o jogo usa principalmente fonte própria em sprites).
- O processo é encerrado ao fechar o app (o jogo guarda muito estado em campos `static`).
