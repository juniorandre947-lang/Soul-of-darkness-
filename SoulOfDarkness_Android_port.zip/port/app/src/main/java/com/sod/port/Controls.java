package com.sod.port;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Controles na tela: D-pad, botoes de acao, softkeys e um teclado numerico (botao 123).
 * Para mudar o mapeamento dos botoes de acao, edite buildButtons().
 * Codigos de tecla = os do J2ME/Nokia usados pelo jogo.
 */
final class Controls {
    interface KeySink { void key(int code, boolean down); }

    static final int UP = -1, DOWN = -2, LEFT = -3, RIGHT = -4, FIRE = -5, SK1 = -6, SK2 = -7, STAR = 42, POUND = 35;

    private static final class Btn {
        final String label; final int key;
        float cx, cy, r, w, h; boolean rect;
        Btn(String l, int k) { label = l; key = k; }
        boolean hit(float x, float y) {
            if (rect) return Math.abs(x - cx) <= w / 2f && Math.abs(y - cy) <= h / 2f;
            float dx = x - cx, dy = y - cy;
            return dx * dx + dy * dy <= r * r * 1.2f;
        }
    }

    final RectF gameRect = new RectF();
    private final List<Btn> btns = new ArrayList<Btn>();
    private final Btn toggle = new Btn("123", 0);
    /** Botao que alterna entre "FIT" (proporcional, altura total) e "FULL" (estica na tela toda). */
    private final Btn modeBtn = new Btn("FIT", 0);
    private boolean numpad;
    private boolean stretch = true;
    private boolean land;
    private float padX, padY, padR, actX, actY, actR;
    private int W, H;
    private final Set<Integer> down = new HashSet<Integer>();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tri = new Path();

    Controls() {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
    }

    synchronized void setStretch(boolean v) { stretch = v; if (W > 0) layout(W, H); }
    synchronized boolean isStretch() { return stretch; }

    synchronized void layout(int w, int h) {
        W = w; H = h;
        land = w > h * 1.15f;
        if (!land) {
            float s = Math.min(w / 240f, (h * 0.60f) / 320f);
            float gw = 240 * s, gh = 320 * s, gx = (w - gw) / 2f, gy = h * 0.02f;
            gameRect.set(gx, gy, gx + gw, gy + gh);
            float y0 = gameRect.bottom, ch = h - y0, u = Math.min(w / 6f, ch / 5f);
            float y1 = y0 + 1.6f * u;
            float midY = (y1 + h) / 2f;
            padR = Math.min(w * 0.22f, (h - y1) / 2f * 0.92f);
            padX = w * 0.25f; padY = midY;
            actX = w * 0.75f; actY = midY; actR = padR;
            setRect(toggle, w / 2f, y0 + 0.75f * u, 1.7f * u, 0.85f * u);
            skRects(w * 0.17f, w * 0.83f, y0 + 0.75f * u, 2.6f * u, 0.9f * u);
        } else {
            // ---- paisagem, estilo PPSSPP ----
            // Jogo: "FIT" = altura total, proporcao 3:4 mantida, centralizado (controles ficam nas faixas
            // laterais). "FULL" = estica para cobrir a tela inteira (distorce) e os controles ficam por cima.
            if (stretch) {
                gameRect.set(0, 0, w, h);
            } else {
                float s = h / 320f;
                float gw = 240 * s, gx = (w - gw) / 2f;
                gameRect.set(gx, 0, gx + gw, h);
            }
            padR = Math.min(h * 0.25f, w * 0.11f);
            float mx = padR * 1.5f;                 // margem da borda (tambem desvia do entalhe da camera)
            padX = mx;       padY = h - padR * 1.25f;   // direcional: canto inferior esquerdo
            actX = w - mx;   actY = padY;  actR = padR; // acao: canto inferior direito
            float bh = h * 0.11f, bw = bh * 2.6f, topY = bh * 0.8f;
            skRects(padX, actX, topY, bw, bh);      // MENU (esq.) e VOLTAR (dir.) no alto, como shoulders
            setRect(modeBtn, padX, topY + bh * 1.3f, bw * 0.7f, bh * 0.9f);
            setRect(toggle, actX, topY + bh * 1.3f, bw * 0.7f, bh * 0.9f);
        }
        buildButtons();
    }

    private Btn sk1, sk2;
    private void skRects(float x1, float x2, float y, float w, float h) {
        sk1 = new Btn("MENU", SK1); setRect(sk1, x1, y, w, h);
        sk2 = new Btn("VOLTAR", SK2); setRect(sk2, x2, y, w, h);
    }
    private static void setRect(Btn b, float cx, float cy, float w, float h) {
        b.rect = true; b.cx = cx; b.cy = cy; b.w = w; b.h = h;
    }
    private static Btn circle(String l, int k, float cx, float cy, float r) {
        Btn b = new Btn(l, k); b.cx = cx; b.cy = cy; b.r = r; return b;
    }

    private void buildButtons() {
        btns.clear();
        if (sk1 != null) { btns.add(sk1); btns.add(sk2); }
        if (!numpad) {
            float d = actR * 0.62f, r = actR * 0.40f;
            btns.add(circle("OK", FIRE, actX, actY + d, r * 1.25f));
            btns.add(circle("5", '5', actX, actY - d, r));
            btns.add(circle("1", '1', actX - d * 1.15f, actY, r));
            btns.add(circle("3", '3', actX + d * 1.15f, actY, r));
        } else {
            float c = actR * 0.46f, r = c * 0.45f;
            String[] rows = {"123", "456", "789", "*0#"};
            btns.add(circle("OK", FIRE, actX, actY - 2.2f * c, r));
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 3; j++) {
                    char ch = rows[i].charAt(j);
                    btns.add(circle(String.valueOf(ch), ch, actX + (j - 1) * c * 1.05f, actY + (i - 1.0f) * c * 1.05f, r));
                }
        }
    }

    private void collect(float x, float y, Set<Integer> want) {
        float dx = x - padX, dy = y - padY, dist = (float) Math.sqrt(dx * dx + dy * dy);
        if (dist <= padR * 1.3f && dist >= padR * 0.15f) {
            float ux = dx / dist, uy = dy / dist;
            if (ux > 0.38f) want.add(RIGHT);
            if (ux < -0.38f) want.add(LEFT);
            if (uy > 0.38f) want.add(DOWN);
            if (uy < -0.38f) want.add(UP);
            return;
        }
        for (Btn b : btns) if (b.hit(x, y)) { want.add(b.key); return; }
    }

    synchronized boolean onTouch(MotionEvent ev, KeySink sink) {
        int action = ev.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int i = ev.getActionIndex();
            if (toggle.hit(ev.getX(i), ev.getY(i))) { numpad = !numpad; buildButtons(); }
            else if (land && modeBtn.hit(ev.getX(i), ev.getY(i))) { stretch = !stretch; layout(W, H); }
        }
        int skip = -1;
        boolean none = action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL;
        if (action == MotionEvent.ACTION_POINTER_UP) skip = ev.getActionIndex();
        Set<Integer> want = new HashSet<Integer>();
        if (!none) {
            for (int i = 0; i < ev.getPointerCount(); i++) {
                if (i == skip) continue;
                collect(ev.getX(i), ev.getY(i), want);
            }
        }
        for (Integer k : new ArrayList<Integer>(down)) if (!want.contains(k)) { down.remove(k); sink.key(k, false); }
        for (Integer k : want) if (!down.contains(k)) { down.add(k); sink.key(k, true); }
        return true;
    }

    synchronized void draw(Canvas cv) {
        if (W == 0) return;
        stroke.setColor(Color.argb(110, 255, 255, 255));
        cv.drawCircle(padX, padY, padR, stroke);
        arrow(cv, UP, padX, padY - padR * 0.55f, 0);
        arrow(cv, DOWN, padX, padY + padR * 0.55f, 180);
        arrow(cv, LEFT, padX - padR * 0.55f, padY, 270);
        arrow(cv, RIGHT, padX + padR * 0.55f, padY, 90);
        for (Btn b : btns) drawBtn(cv, b);
        drawBtn(cv, toggle);
        if (land) drawBtn(cv, modeBtn);
    }

    private void drawBtn(Canvas cv, Btn b) {
        boolean on = b != toggle && down.contains(b.key);
        fill.setStyle(Paint.Style.FILL);
        boolean over = land && stretch; // por cima do jogo: mais transparente
        fill.setColor(Color.argb(on ? 140 : (over ? 28 : 60), 255, 255, 255));
        stroke.setColor(Color.argb(over ? 85 : 120, 255, 255, 255));
        if (b.rect) {
            RectF rf = new RectF(b.cx - b.w / 2, b.cy - b.h / 2, b.cx + b.w / 2, b.cy + b.h / 2);
            cv.drawRoundRect(rf, b.h / 2, b.h / 2, fill);
            cv.drawRoundRect(rf, b.h / 2, b.h / 2, stroke);
            text.setTextSize(b.h * 0.42f);
        } else {
            cv.drawCircle(b.cx, b.cy, b.r, fill);
            cv.drawCircle(b.cx, b.cy, b.r, stroke);
            text.setTextSize(b.r * 0.85f);
        }
        text.setColor(Color.argb(land && stretch ? 190 : 230, 255, 255, 255));
        String label = b == toggle ? (numpad ? "AÇÃO" : "123") : b == modeBtn ? (stretch ? "FULL" : "FIT") : b.label;
        cv.drawText(label, b.cx, b.cy + text.getTextSize() * 0.35f, text);
    }

    private void arrow(Canvas cv, int key, float x, float y, float deg) {
        float t = padR * 0.2f;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.argb(down.contains(key) ? 190 : 90, 255, 255, 255));
        cv.save();
        cv.rotate(deg, x, y);
        tri.reset();
        tri.moveTo(x, y - t);
        tri.lineTo(x + t, y + t * 0.7f);
        tri.lineTo(x - t, y + t * 0.7f);
        tri.close();
        cv.drawPath(tri, fill);
        cv.restore();
    }
}
