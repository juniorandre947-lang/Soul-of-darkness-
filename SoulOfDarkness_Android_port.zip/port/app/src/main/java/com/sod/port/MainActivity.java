package com.sod.port;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import javax.microedition.lcdui.Display;
import javax.microedition.media.Manager;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

public class MainActivity extends Activity implements MIDlet.Host {
    private static final String TAG = "SOD";
    private GameSurface surface;
    private MIDlet midlet;
    private volatile boolean started;
    private final Map<String, String> props = new HashMap<String, String>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        DebugLog.install();
        // diagnostico: os arquivos do jogo (0..24, dataIGP, png) estao dentro do APK?
        int ok = 0, total = 0;
        StringBuilder miss = new StringBuilder();
        java.util.ArrayList<String> names = new java.util.ArrayList<String>();
        for (int i = 0; i <= 24; i++) names.add(String.valueOf(i));
        names.add("dataIGP"); names.add("logo.png"); names.add("new.png"); names.add("icon.png");
        for (String n : names) {
            total++;
            try {
                InputStream in = MainActivity.class.getResourceAsStream("/" + n);
                if (in == null) miss.append(n).append(' ');
                else { ok++; in.close(); }
            } catch (Exception e) { miss.append(n).append('!').append(' '); }
        }
        System.out.println("RES ok=" + ok + "/" + total + " faltando: " + miss);
        loadManifest();
        RecordStore.init(getFilesDir());
        Manager.setCacheDir(getCacheDir());
        surface = new GameSurface(this);
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread th, Throwable t) {
                // erro numa thread do jogo: mostra na tela em vez de morrer calado
                if (th == Looper.getMainLooper().getThread()) { if (old != null) old.uncaughtException(th, t); return; }
                surface.showError("thread " + th.getName(), t);
            }
        });
        setContentView(surface);
        Display.host = surface;
        MIDlet.host = this;
    }

    private void loadManifest() {
        try {
            InputStream in = getAssets().open("jar-manifest.txt");
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                int i = line.indexOf(':');
                if (i > 0) props.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
            }
            r.close();
        } catch (Exception e) {
            Log.e(TAG, "manifest", e);
        }
    }

    /** MIDlet-1: nome, icone, classe */
    private String midletClass() {
        String v = props.get("MIDlet-1");
        if (v != null) {
            String[] p = v.split(",");
            if (p.length >= 3) return p[2].trim();
        }
        return "GloftSOFD";
    }

    @Override protected void onResume() {
        super.onResume();
        hideSystemUi();
        if (!started) {
            started = true;
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        midlet = (MIDlet) Class.forName(midletClass()).getDeclaredConstructor().newInstance();
                        midlet.__start();
                    } catch (Throwable t) {
                        surface.showError("falha ao iniciar o MIDlet", t);
                    }
                }
            }, "midlet-start").start();
        } else if (midlet != null) {
            try { midlet.__start(); } catch (Throwable t) { Log.e(TAG, "resume", t); }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (midlet != null) { try { midlet.__pause(); } catch (Throwable t) { Log.e(TAG, "pause", t); } }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (midlet != null) { try { midlet.__destroy(); } catch (Throwable ignore) { } }
        // o jogo usa muitos campos static: matar o processo garante um inicio limpo na proxima vez
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) hideSystemUi();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ---- teclado fisico / gamepad ----
    private static int map(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP: return Controls.UP;
            case KeyEvent.KEYCODE_DPAD_DOWN: return Controls.DOWN;
            case KeyEvent.KEYCODE_DPAD_LEFT: return Controls.LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return Controls.RIGHT;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A: return Controls.FIRE;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_BUTTON_START: return Controls.SK1;
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_BUTTON_B: return Controls.SK2;
            case KeyEvent.KEYCODE_STAR: return Controls.STAR;
            case KeyEvent.KEYCODE_POUND: return Controls.POUND;
            default:
                if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) return '0' + (k - KeyEvent.KEYCODE_0);
                return 0;
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        int code = map(e.getKeyCode());
        if (code == 0) return super.dispatchKeyEvent(e);
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) surface.key(code, true);
        } else if (e.getAction() == KeyEvent.ACTION_UP) {
            surface.key(code, false);
        }
        return true;
    }

    // ---- MIDlet.Host ----
    @Override public void notifyDestroyed() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override public void run() { finish(); }
        });
    }

    @Override public String getAppProperty(String key) { return props.get(key); }

    @Override public boolean platformRequest(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Log.w(TAG, "platformRequest " + url, e);
        }
        return false; // false = o app nao precisa fechar
    }
}
