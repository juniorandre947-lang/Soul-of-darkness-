package com.sod.port;

import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/** Captura System.out/err do jogo (ele usa printStackTrace) para mostrar no painel de diagnostico. */
final class DebugLog {
    private static final LinkedList<String> lines = new LinkedList<String>();
    private static final StringBuilder cur = new StringBuilder();
    private static boolean installed;
    private static final ArrayList<String> head = new ArrayList<String>();

    static synchronized void install() {
        if (installed) return;
        installed = true;
        System.setOut(new PrintStream(new Tee(System.out), true));
        System.setErr(new PrintStream(new Tee(System.err), true));
    }

    private static final class Tee extends OutputStream {
        private final OutputStream o;
        Tee(OutputStream o) { this.o = o; }
        @Override public void write(int b) {
            try { o.write(b); } catch (Exception ignore) { }
            add(b);
        }
        @Override public void write(byte[] b, int off, int len) {
            try { o.write(b, off, len); } catch (Exception ignore) { }
            for (int i = 0; i < len; i++) add(b[off + i]);
        }
    }

    private static synchronized void add(int b) {
        if (b == '\n') {
            if (head.size() < 30) head.add(cur.toString());
            lines.add(cur.toString());
            cur.setLength(0);
            while (lines.size() > 40) lines.removeFirst();
        } else if (b != '\r' && cur.length() < 300) {
            cur.append((char) (b & 0xFF));
        }
    }

    static synchronized List<String> head(int n) {
        return new ArrayList<String>(head.subList(0, Math.min(n, head.size())));
    }

    static synchronized List<String> last(int n) {
        int from = Math.max(0, lines.size() - n);
        return new ArrayList<String>(lines.subList(from, lines.size()));
    }
}
