package com.sod.port;

/**
 * O jogo faz "texto".getClass().getResourceAsStream("/N"). No J2ME isso acha os arquivos do jar,
 * mas no Android String.class vem do sistema e nao enxerga os recursos do app. O game.jar foi
 * ajustado para chamar Res.c(obj) no lugar de obj.getClass(): devolve uma classe do app.
 */
public final class Res {
    private Res() { }
    public static Class<?> c(Object o) { return Res.class; }
}
