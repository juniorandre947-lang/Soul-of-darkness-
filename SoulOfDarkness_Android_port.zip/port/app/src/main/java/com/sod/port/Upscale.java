package com.sod.port;

/**
 * Ampliadores em Java puro (sem Android), sobre pixels ARGB nao-premultiplicados.
 *  - pixelArt4x: EPX/Scale2x aplicado duas vezes (bordas nitidas, nenhuma cor nova -> ideal p/ sprites).
 *  - smooth: bicubico Catmull-Rom em espaco premultiplicado (ideal p/ fundos pintados).
 */
public final class Upscale {
    private Upscale() { }

    /** Imagem parece sprite/HUD? (tem transparencia ou e pequena) -> usa pixel art; senao suave. */
    public static boolean looksLikeSprite(int[] px, int w, int h) {
        if (Math.max(w, h) <= 64) return true;
        int clear = 0;
        for (int p : px) if ((p >>> 24) < 128) clear++;
        return clear * 50L > px.length;   // > 2% transparente
    }

    public static int[] auto(int[] px, int w, int h, int scale) {
        if (looksLikeSprite(px, w, h)) return pixelArt(px, w, h, scale);
        return smooth(dedither(px, w, h, 96), w, h, scale);
    }

    /**
     * Tira o quadriculado (dithering) dos fundos: filtro bilateral 3x3. Pixels vizinhos de cor parecida
     * (diferenca soma R+G+B < thr) sao misturados; bordas fortes (diferenca grande) ficam intactas.
     */
    public static int[] dedither(int[] px, int w, int h, int thr) {
        int[] out = px.clone();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = px[y * w + x];
                if ((c >>> 24) != 255) continue;
                int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
                float sw = 2f, sr = 2f * cr, sg = 2f * cg, sb = 2f * cb;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy; if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        int xx = x + dx; if (xx < 0 || xx >= w) continue;
                        int n = px[yy * w + xx];
                        if ((n >>> 24) != 255) continue;
                        int nr = (n >> 16) & 255, ng = (n >> 8) & 255, nb = n & 255;
                        int d = Math.abs(nr - cr) + Math.abs(ng - cg) + Math.abs(nb - cb);
                        if (d >= thr) continue;
                        float k = 1f - (float) d / thr;
                        sw += k; sr += k * nr; sg += k * ng; sb += k * nb;
                    }
                }
                out[y * w + x] = 0xFF000000 | (Math.round(sr / sw) << 16) | (Math.round(sg / sw) << 8) | Math.round(sb / sw);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ pixel art
    /** scale precisa ser potencia de 2 (2, 4, 8). */
    public static int[] pixelArt(int[] px, int w, int h, int scale) {
        int[] cur = px.clone();
        for (int i = 0; i < cur.length; i++) if ((cur[i] >>> 24) == 0) cur[i] = 0;  // todo transparente igual
        int cw = w, ch = h;
        for (int s = 1; s < scale; s *= 2) {
            cur = epx(cur, cw, ch);
            cw *= 2; ch *= 2;
        }
        return cur;
    }

    private static int[] epx(int[] s, int w, int h) {
        int W = w * 2;
        int[] d = new int[W * h * 2];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int P = s[y * w + x];
                int A = y > 0 ? s[(y - 1) * w + x] : P;        // cima
                int B = x < w - 1 ? s[y * w + x + 1] : P;      // direita
                int C = x > 0 ? s[y * w + x - 1] : P;          // esquerda
                int D = y < h - 1 ? s[(y + 1) * w + x] : P;    // baixo
                int p1 = P, p2 = P, p3 = P, p4 = P;
                if (C == A && C != D && A != B) p1 = A;
                if (A == B && A != C && B != D) p2 = B;
                if (D == C && D != B && C != A) p3 = C;
                if (B == D && B != A && D != C) p4 = D;
                int o = (y * 2) * W + x * 2;
                d[o] = p1; d[o + 1] = p2; d[o + W] = p3; d[o + W + 1] = p4;
            }
        }
        return d;
    }

    // ------------------------------------------------------------------ suave (Catmull-Rom)
    public static int[] smooth(int[] px, int w, int h, int scale) {
        int W = w * scale, H = h * scale;
        // pesos por fase (a amostra de saida cai sempre na mesma posicao relativa)
        int[] base = new int[scale];
        float[][] wt = new float[scale][4];
        for (int o = 0; o < scale; o++) {
            float u = (o + 0.5f) / scale - 0.5f;
            int i0 = (int) Math.floor(u);
            float f = u - i0;
            base[o] = i0 - 1;
            float f2 = f * f, f3 = f2 * f;
            wt[o][0] = -0.5f * f3 + f2 - 0.5f * f;
            wt[o][1] = 1.5f * f3 - 2.5f * f2 + 1f;
            wt[o][2] = -1.5f * f3 + 2f * f2 + 0.5f * f;
            wt[o][3] = 0.5f * f3 - 0.5f * f2;
        }
        // premultiplica: canais a,r,g,b em float
        float[] pa = new float[w * h], pr = new float[w * h], pg = new float[w * h], pb = new float[w * h];
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            float a = (p >>> 24) / 255f;
            pa[i] = a;
            pr[i] = ((p >> 16) & 255) * a;
            pg[i] = ((p >> 8) & 255) * a;
            pb[i] = (p & 255) * a;
        }
        // passo horizontal: h linhas x W colunas
        float[][] ha = hpass(pa, w, h, W, scale, base, wt);
        float[][] hr = hpass(pr, w, h, W, scale, base, wt);
        float[][] hg = hpass(pg, w, h, W, scale, base, wt);
        float[][] hb = hpass(pb, w, h, W, scale, base, wt);
        int[] out = new int[W * H];
        for (int Y = 0; Y < H; Y++) {
            int sy = Y / scale, o = Y % scale;
            float[] w4 = wt[o];
            int y0 = sy + base[o];
            for (int X = 0; X < W; X++) {
                float a = 0, r = 0, g = 0, b = 0;
                for (int k = 0; k < 4; k++) {
                    int yy = y0 + k; if (yy < 0) yy = 0; else if (yy >= h) yy = h - 1;
                    float wk = w4[k];
                    a += ha[yy][X] * wk; r += hr[yy][X] * wk; g += hg[yy][X] * wk; b += hb[yy][X] * wk;
                }
                if (a < 0.002f) { out[Y * W + X] = 0; continue; }
                if (a > 1f) a = 1f;
                int ia = Math.round(a * 255f);
                int ir = clamp(Math.round(r / a)), ig = clamp(Math.round(g / a)), ib = clamp(Math.round(b / a));
                out[Y * W + X] = (ia << 24) | (ir << 16) | (ig << 8) | ib;
            }
        }
        return out;
    }

    private static float[][] hpass(float[] src, int w, int h, int W, int scale, int[] base, float[][] wt) {
        float[][] out = new float[h][W];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int X = 0; X < W; X++) {
                int sx = X / scale, o = X % scale;
                float[] w4 = wt[o];
                int x0 = sx + base[o];
                float v = 0;
                for (int k = 0; k < 4; k++) {
                    int xx = x0 + k; if (xx < 0) xx = 0; else if (xx >= w) xx = w - 1;
                    v += src[row + xx] * w4[k];
                }
                out[y][X] = v;
            }
        }
        return out;
    }

    private static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }
}
