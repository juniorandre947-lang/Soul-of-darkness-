package com.sod.port;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.CRC32;

/**
 * Remaster em alta resolucao.
 *
 * O jogo continua rodando em 240x320 (logica, colisao, posicoes). Cada imagem que ele carrega ganha
 * uma versao SCALE vezes maior, e o quadro final e desenhado em SCALE*240 x SCALE*320.
 * De onde vem a versao grande, em ordem:
 *   1) um arquivo pronto  hd/<crc>.png  (pasta Android/data/com.sod.port/files/hd/ ou assets/hd/),
 *      feito por tools/upscale_hd.py (IA nos fundos, pixel art nos sprites);
 *   2) senao, ampliacao automatica na hora (Upscale: EPX nos sprites, bicubico nos fundos).
 * <crc> = CRC32 (8 hex) dos bytes exatos do PNG que o jogo entregou a Image.createImage.
 */
public final class HdPack {
    private HdPack() { }

    /** Fator de ampliacao (potencia de 2: 1 = original, 2, 4, 8). 4 -> quadro de 960x1280. */
    public static final int SCALE = 4;
    /** Grava cada PNG que o jogo cria em files/dump/<crc>.png, para ampliar com tools/upscale_hd.py. */
    public static final boolean DUMP = true;

    private static final String TAG = "SOD";
    private static Context ctx;
    private static File hdDir, dumpDir;
    private static final java.util.HashSet<Long> dumped = new java.util.HashSet<Long>();

    public static void init(Context c) {
        ctx = c.getApplicationContext();
        File base = ctx.getExternalFilesDir(null);
        if (base == null) base = ctx.getFilesDir();
        hdDir = new File(base, "hd");
        dumpDir = new File(base, "dump");
        if (DUMP) dumpDir.mkdirs();
        hdDir.mkdirs();
        Log.i(TAG, "HdPack: escala " + SCALE + "x, pasta " + base);
    }

    public static long crc(byte[] d, int off, int len) {
        CRC32 c = new CRC32();
        c.update(d, off, len);
        return c.getValue();
    }

    private static String name(long key) {
        String h = Long.toHexString(key);
        while (h.length() < 8) h = "0" + h;
        return h + ".png";
    }

    /** Grava o PNG original (uma vez por imagem diferente). */
    public static void dump(long key, byte[] d, int off, int len) {
        if (!DUMP || dumpDir == null) return;
        synchronized (dumped) { if (!dumped.add(key)) return; }
        try {
            FileOutputStream o = new FileOutputStream(new File(dumpDir, name(key)));
            try { o.write(d, off, len); } finally { o.close(); }
        } catch (Throwable ignore) { }
    }

    /** Versao pronta (hd/<crc>.png); so vale se tiver exatamente SCALE x o tamanho original. */
    public static Bitmap lookup(long key, int w, int h) {
        if (ctx == null) return null;
        String n = name(key);
        try {
            Bitmap b = null;
            File f = new File(hdDir, n);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            if (f.isFile()) {
                b = BitmapFactory.decodeFile(f.getPath(), o);
            } else {
                InputStream in = null;
                try { in = ctx.getAssets().open("hd/" + n); b = BitmapFactory.decodeStream(in, null, o); }
                catch (java.io.IOException noAsset) { b = null; }
                finally { if (in != null) { try { in.close(); } catch (java.io.IOException ignore) { } } }
            }
            if (b != null && b.getWidth() == w * SCALE && b.getHeight() == h * SCALE) return b;
            if (b != null) Log.w(TAG, "HdPack: " + n + " com tamanho errado, ignorado");
        } catch (Throwable t) {
            Log.w(TAG, "HdPack: falha lendo " + n + ": " + t);
        }
        return null;
    }

    /** Ampliacao automatica do bitmap original. */
    public static Bitmap autoScale(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] out = Upscale.auto(px, w, h, SCALE);
        return Bitmap.createBitmap(out, w * SCALE, h * SCALE, Bitmap.Config.ARGB_8888);
    }
}
