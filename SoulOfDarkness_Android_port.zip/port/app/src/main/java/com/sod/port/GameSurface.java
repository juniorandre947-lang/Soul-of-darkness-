package com.sod.port;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

/** Superficie que mostra o quadro 240x320 do jogo (escalado) e os controles na tela. */
public class GameSurface extends SurfaceView implements SurfaceHolder.Callback, Display.Host, Controls.KeySink {
    /** true = escala suavizada; false = pixels nitidos. */
    private static final boolean SMOOTH = false;

    private final Bitmap frame = Bitmap.createBitmap(Display.WIDTH, Display.HEIGHT, Bitmap.Config.ARGB_8888);
    private final Graphics fg = new Graphics(frame);
    private final Object lock = new Object();
    private final Paint blit = new Paint();
    private final Rect srcR = new Rect(0, 0, Display.WIDTH, Display.HEIGHT);
    private final Rect dstR = new Rect();
    private final Controls controls = new Controls();
    private volatile boolean ready;

    public GameSurface(Context ctx) {
        super(ctx);
        blit.setFilterBitmap(SMOOTH);
        getHolder().addCallback(this);
        setFocusable(true);
    }

    // ---- Display.Host: chamado pela thread do jogo ----
    private volatile String errText;
    private final Paint errPaint = new Paint();

    /** Registra um erro (aparece em vermelho na tela e no Logcat, filtro SOD). */
    public void showError(String where, Throwable t) {
        android.util.Log.e("SOD", where, t);
        StringBuilder sb = new StringBuilder(where).append(": ").append(t);
        StackTraceElement[] st = t.getStackTrace();
        for (int i = 0; i < st.length && i < 6; i++) sb.append("\n  ").append(st[i]);
        if (t.getCause() != null) sb.append("\nCausa: ").append(t.getCause());
        errText = sb.toString();
        present();
    }

    @Override public void repaint(Canvas c) {
        try {
            synchronized (lock) {
                fg.resetClip();
                c.__paint(fg);
            }
        } catch (Throwable t) {
            showError("paint()", t);
            return;
        }
        String e = errText;
        if (e != null && e.startsWith("paint()")) errText = null; // erro de um quadro isolado some no proximo quadro bom
        present();
    }

    private void drawError(android.graphics.Canvas cv) {
        String e = errText;
        if (e == null) return;
        errPaint.setColor(Color.argb(210, 0, 0, 0));
        cv.drawRect(0, 0, cv.getWidth(), cv.getHeight() * 0.6f, errPaint);
        errPaint.setColor(Color.rgb(255, 80, 80));
        errPaint.setTextSize(cv.getWidth() / 36f);
        float y = errPaint.getTextSize() * 1.5f;
        for (String line : e.split("\n")) {
            while (line.length() > 0) {
                int n = errPaint.breakText(line, true, cv.getWidth() - 20f, null);
                if (n <= 0) break;
                cv.drawText(line.substring(0, n), 10f, y, errPaint);
                y += errPaint.getTextSize() * 1.2f;
                line = line.substring(n);
            }
        }
    }

    private void present() {
        if (!ready) return;
        SurfaceHolder h = getHolder();
        android.graphics.Canvas cv = null;
        try {
            cv = h.lockCanvas();
            if (cv == null) return;
            cv.drawColor(Color.BLACK);
            RectF g = controls.gameRect;
            dstR.set(Math.round(g.left), Math.round(g.top), Math.round(g.right), Math.round(g.bottom));
            synchronized (lock) { cv.drawBitmap(frame, srcR, dstR, blit); }
            controls.draw(cv);
            drawError(cv);
        } catch (RuntimeException ignore) {
        } finally {
            if (cv != null) { try { h.unlockCanvasAndPost(cv); } catch (RuntimeException ignore) { } }
        }
    }

    // ---- teclas (touch e teclado fisico) ----
    @Override public void key(int code, boolean down) {
        Canvas c = Display.currentCanvas();
        if (c == null) return;
        if (down) c.__keyPressed(code); else c.__keyReleased(code);
    }

    @Override public boolean onTouchEvent(MotionEvent ev) { return controls.onTouch(ev, this); }

    @Override public void surfaceCreated(SurfaceHolder holder) { ready = true; }
    @Override public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        controls.layout(w, h);
        present(); // redesenha o ultimo quadro (senao fica preto ate o jogo repintar)
    }
    @Override public void surfaceDestroyed(SurfaceHolder holder) { ready = false; }
}
