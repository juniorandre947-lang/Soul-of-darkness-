package com.sod.port;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

/** Superficie que mostra o quadro 240x320 do jogo (escalado) e os controles na tela. */
public class GameSurface extends SurfaceView implements SurfaceHolder.Callback, Display.Host, Controls.KeySink {
    /** true = escala suavizada; false = pixels nitidos. */
    private static final boolean SMOOTH = false;

    private final Bitmap frame = Bitmap.createBitmap(Display.WIDTH, Display.HEIGHT, Bitmap.Config.ARGB_8888);
    private final Graphics fg = new Graphics(frame);
    private final Object lock = new Object();
    private final Paint blit = new Paint();
    private final Rect srcR = new Rect(0, 0, Display.WIDTH, Display.HEIGHT);
    private final Rect dstR = new Rect();
    private final Controls controls = new Controls();
    private volatile boolean ready;

    public GameSurface(Context ctx) {
        super(ctx);
        blit.setFilterBitmap(SMOOTH);
        getHolder().addCallback(this);
        setFocusable(true);
    }

    // ---- Display.Host: chamado pela thread do jogo ----
    @Override public void repaint(Canvas c) {
        synchronized (lock) {
            fg.resetClip();
            c.__paint(fg);
        }
        present();
    }

    private void present() {
        if (!ready) return;
        SurfaceHolder h = getHolder();
        android.graphics.Canvas cv = null;
        try {
            cv = h.lockCanvas();
            if (cv == null) return;
            cv.drawColor(Color.BLACK);
            RectF g = controls.gameRect;
            dstR.set(Math.round(g.left), Math.round(g.top), Math.round(g.right), Math.round(g.bottom));
            synchronized (lock) { cv.drawBitmap(frame, srcR, dstR, blit); }
            controls.draw(cv);
        } catch (RuntimeException ignore) {
        } finally {
            if (cv != null) { try { h.unlockCanvasAndPost(cv); } catch (RuntimeException ignore) { } }
        }
    }

    // ---- teclas (touch e teclado fisico) ----
    @Override public void key(int code, boolean down) {
        Canvas c = Display.currentCanvas();
        if (c == null) return;
        if (down) c.__keyPressed(code); else c.__keyReleased(code);
    }

    @Override public boolean onTouchEvent(MotionEvent ev) { return controls.onTouch(ev, this); }

    @Override public void surfaceCreated(SurfaceHolder holder) { ready = true; }
    @Override public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) { controls.layout(w, h); }
    @Override public void surfaceDestroyed(SurfaceHolder holder) { ready = false; }
}
