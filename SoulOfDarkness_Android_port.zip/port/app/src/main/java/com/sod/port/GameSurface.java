package com.sod.port;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

/** Superficie que mostra o quadro 240x320 do jogo (escalado) e os controles na tela. */
public class GameSurface extends SurfaceView implements SurfaceHolder.Callback, Display.Host, Controls.KeySink {
    /** true = escala suavizada; false = pixels nitidos. */
    private static final boolean SMOOTH = false;

    private final Bitmap frame = Bitmap.createBitmap(Display.WIDTH, Display.HEIGHT, Bitmap.Config.ARGB_8888);
    private final Graphics fg = new Graphics(frame);
    private final Object lock = new Object();
    private final Paint blit = new Paint();
    private final Rect srcR = new Rect(0, 0, Display.WIDTH, Display.HEIGHT);
    private final Rect dstR = new Rect();
    private final Controls controls = new Controls();
    private volatile boolean ready;
    private final Object presentLock = new Object();
    private volatile int paints;
    private final long startMs = System.currentTimeMillis();
    private volatile String dbgText = "";
    private volatile boolean dbgShow = true;
    private boolean dbgThreadOn;
    /** Painel de diagnostico (texto no topo da tela). Ponha false depois que tudo funcionar. */
    static final boolean DEBUG = false;

    public GameSurface(Context ctx) {
        super(ctx);
        blit.setFilterBitmap(SMOOTH);
        getHolder().addCallback(this);
        setFocusable(true);
    }

    // ---- Display.Host: chamado pela thread do jogo ----
    private volatile String errText;
    private final Paint errPaint = new Paint();

    /** Registra um erro (aparece em vermelho na tela e no Logcat, filtro SOD). */
    public void showError(String where, Throwable t) {
        android.util.Log.e("SOD", where, t);
        StringBuilder sb = new StringBuilder(where).append(": ").append(t);
        StackTraceElement[] st = t.getStackTrace();
        for (int i = 0; i < st.length && i < 6; i++) sb.append("\n  ").append(st[i]);
        if (t.getCause() != null) sb.append("\nCausa: ").append(t.getCause());
        errText = sb.toString();
        present();
    }

    @Override public void repaint(Canvas c) {
        try {
            synchronized (lock) {
                fg.resetClip();
                c.__paint(fg);
            }
            paints++;
        } catch (Throwable t) {
            showError("paint()", t);
            return;
        }
        String e = errText;
        if (e != null && e.startsWith("paint()")) errText = null; // erro de um quadro isolado some no proximo quadro bom
        present();
    }

    private String buildDebug() {
        StringBuilder sb = new StringBuilder();
        Canvas cc = Display.currentCanvas();
        int nonBlack = 0, total = 0;
        synchronized (lock) {
            for (int y = 4; y < Display.HEIGHT; y += 8)
                for (int x = 4; x < Display.WIDTH; x += 8) {
                    total++;
                    if ((frame.getPixel(x, y) & 0xFFFFFF) != 0) nonBlack++;
                }
        }
        dbgShow = nonBlack == 0 || errText != null; // some quando o jogo ja aparece na tela
        sb.append("t=").append((System.currentTimeMillis() - startMs) / 1000).append("s paints=").append(paints)
          .append(" canvas=").append(cc == null ? "NULL" : cc.getClass().getName())
          .append(" naoPreto=").append(nonBlack).append('/').append(total).append('\n');
        for (java.util.Map.Entry<Thread, StackTraceElement[]> e : Thread.getAllStackTraces().entrySet()) {
            StackTraceElement[] st = e.getValue();
            String game = null;
            for (StackTraceElement f : st) {
                String c = f.getClassName();
                if (c.length() <= 2 || c.startsWith("Gloft")) { game = f.toString(); break; }
            }
            if (game == null) continue;
            sb.append("[").append(e.getKey().getName()).append(" ").append(e.getKey().getState()).append("] ")
              .append(game);
            if (st.length > 0) sb.append(" <- ").append(st[0]);
            sb.append('\n');
        }
        sb.append("--- PRIMEIRAS LINHAS ---\n");
        for (String l : DebugLog.head(18)) sb.append("> ").append(l).append('\n');
        sb.append("--- ULTIMAS ---\n");
        for (String l : DebugLog.last(6)) sb.append("> ").append(l).append('\n');
        return sb.toString();
    }

    private void startDebugThread() {
        if (!DEBUG || dbgThreadOn) return;
        dbgThreadOn = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
                    try { dbgText = buildDebug(); present(); } catch (Throwable ignore) { }
                }
            }
        }, "dbg-refresh");
        t.setDaemon(true);
        t.start();
    }

    private void drawStatus(android.graphics.Canvas cv) {
        String st = Hook.status;
        if (st == null) return;
        errPaint.setTextSize(cv.getWidth() / 70f);
        errPaint.setColor(Color.argb(170, 0, 0, 0));
        cv.drawRect(0, 0, errPaint.measureText(st) + 16f, errPaint.getTextSize() * 1.6f, errPaint);
        errPaint.setColor(Color.YELLOW);
        cv.drawText(st, 8f, errPaint.getTextSize() * 1.2f, errPaint);
    }

    private void drawDebug(android.graphics.Canvas cv) {
        if (!DEBUG || !dbgShow) return;
        String e = dbgText;
        if (e.length() == 0) return;
        float ts = cv.getWidth() / 46f;
        errPaint.setTextSize(ts);
        float y = cv.getHeight() * 0.03f;
        errPaint.setColor(Color.argb(200, 0, 0, 0));
        cv.drawRect(0, 0, cv.getWidth(), cv.getHeight() * 0.64f, errPaint);
        errPaint.setColor(Color.rgb(120, 255, 120));
        float limit = cv.getHeight() * 0.64f;
        for (String line : e.split("\n")) {
            while (line.length() > 0 && y < limit) {
                int n = errPaint.breakText(line, true, cv.getWidth() - 20f, null);
                if (n <= 0) break;
                cv.drawText(line.substring(0, n), 10f, y, errPaint);
                y += ts * 1.15f;
                line = line.substring(n);
            }
        }
    }

    private void drawError(android.graphics.Canvas cv) {
        String e = errText;
        if (e == null) return;
        errPaint.setColor(Color.argb(210, 0, 0, 0));
        cv.drawRect(0, 0, cv.getWidth(), cv.getHeight() * 0.6f, errPaint);
        errPaint.setColor(Color.rgb(255, 80, 80));
        errPaint.setTextSize(cv.getWidth() / 36f);
        float y = errPaint.getTextSize() * 1.5f;
        for (String line : e.split("\n")) {
            while (line.length() > 0) {
                int n = errPaint.breakText(line, true, cv.getWidth() - 20f, null);
                if (n <= 0) break;
                cv.drawText(line.substring(0, n), 10f, y, errPaint);
                y += errPaint.getTextSize() * 1.2f;
                line = line.substring(n);
            }
        }
    }

    private void present() {
        if (!ready) return;
        synchronized (presentLock) { presentLocked(); }
    }

    private void presentLocked() {
        SurfaceHolder h = getHolder();
        android.graphics.Canvas cv = null;
        try {
            cv = h.lockCanvas();
            if (cv == null) return;
            cv.drawColor(Color.BLACK);
            RectF g = controls.gameRect;
            dstR.set(Math.round(g.left), Math.round(g.top), Math.round(g.right), Math.round(g.bottom));
            synchronized (lock) { cv.drawBitmap(frame, srcR, dstR, blit); }
            controls.draw(cv);
            drawError(cv);
            drawDebug(cv);
            drawStatus(cv);
        } catch (RuntimeException ignore) {
        } finally {
            if (cv != null) { try { h.unlockCanvasAndPost(cv); } catch (RuntimeException ignore) { } }
        }
    }

    // ---- teclas (touch e teclado fisico) ----
    @Override public void key(int code, boolean down) {
        Canvas c = Display.currentCanvas();
        if (c == null) return;
        if (down) c.__keyPressed(code); else c.__keyReleased(code);
    }

    @Override public boolean onTouchEvent(MotionEvent ev) { return controls.onTouch(ev, this); }

    @Override public void surfaceCreated(SurfaceHolder holder) { ready = true; startDebugThread(); }
    @Override public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        controls.layout(w, h);
        present(); // redesenha o ultimo quadro (senao fica preto ate o jogo repintar)
    }
    @Override public void surfaceDestroyed(SurfaceHolder holder) { ready = false; }
}
