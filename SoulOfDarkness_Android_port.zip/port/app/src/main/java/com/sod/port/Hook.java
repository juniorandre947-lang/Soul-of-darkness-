package com.sod.port;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * EXPERIMENTO multiplayer, passo 2: o segundo heroi (clone do primeiro) e controlado pelos botoes do convidado (rede).
 * O game.jar foi ajustado para chamar estes metodos no lugar de:
 *   e.ak()  (atualiza o heroi e os inimigos)  -> Hook.ak()
 *   e.ao()  (desenha a fase)                  -> Hook.ao()
 *   putstatic e.bL (guarda o heroi)           -> Hook.setHero(obj)
 */
public final class Hook {
    private Hook() { }

    /** Texto curto mostrado no canto da tela (GameSurface). */
    public static volatile String status = null;

    /** O heroi 2 so existe quando sou o anfitriao e ha um convidado conectado. */
    private static boolean active() {
        return Net.role == Net.HOST && Net.connected();
    }

    private static int curHeld, curPressed, prevHeld;
    /** Botoes de movimento valem enquanto segurados; os demais (ataque etc.) valem so no instante do toque. */
    private static final int HELD_BITS = 4096 | 8192 | 16384 | 32768 | 4 | 16 | 64 | 256 | 2 | 8;
    private static final int SOFTKEYS = 131072 | 262144;

    private static Class<?> E, B, D;
    private static Field eBL;
    private static Field[] heldKeys, allKeys;
    private static Method eAk, eAo, bT, bV;
    private static Object hero1, hero2;
    private static boolean failed;
    private static int frame, errors;
    private static String lastErr = "";

    private static void init() throws Exception {
        if (E != null) return;
        E = Class.forName("e");
        B = Class.forName("b");
        D = Class.forName("d");
        eBL = field(E, "bL");
        heldKeys = new Field[] { field(E, "df"), field(E, "di"), field(E, "dh") };
        allKeys = new Field[] { field(E, "dg"), field(E, "dh"), field(E, "di"), field(E, "dl"),
                field(E, "df"), field(E, "dk"), field(E, "dm") };
        eAk = method(E, "ak");
        eAo = method(E, "ao");
        bT = method(B, "t");
        bV = method(B, "v");
    }

    private static Field field(Class<?> c, String n) throws Exception {
        Field f = c.getDeclaredField(n);
        f.setAccessible(true);
        return f;
    }

    private static Method method(Class<?> c, String n) throws Exception {
        Method m = c.getDeclaredMethod(n);
        m.setAccessible(true);
        return m;
    }

    private static void log(String s) {
        System.out.println("HOOK " + s);
    }

    private static void callOriginal(Method m) {
        try {
            m.invoke(null);
        } catch (InvocationTargetException ite) {
            Throwable c = ite.getCause();
            if (c instanceof RuntimeException) throw (RuntimeException) c;
            if (c instanceof Error) throw (Error) c;
            throw new RuntimeException(c);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    // ---------------------------------------------------------------- ganchos chamados pelo jogo

    public static void setHero(Object o) {
        try {
            init();
            eBL.set(null, o);
        } catch (Throwable t) {
            log("setHero: " + t);
        }
        if (o != hero1) { hero1 = o; hero2 = null; }
    }

    public static void ak() {
        try { init(); } catch (Throwable t) { failed = true; status = "H2 erro init: " + t; }
        if (failed || E == null) { callOriginalSafe(true); return; }
        callOriginal(eAk);                      // heroi 1 + inimigos, como sempre
        if (!active()) { hero2 = null; return; }
        try {
            Object h = eBL.get(null);
            if (h == null) return;
            if (h != hero1) { hero1 = h; hero2 = null; }
            if (hero2 == null) {
                hero2 = cloneHero(h);
                prevHeld = 0;
                log("heroi 2 criado");
                status = "Jogador 2 na partida";
            }
            // botoes do convidado -> teclas do jogo
            int held = Net.remoteBits() & ~SOFTKEYS;
            int edge = held & ~prevHeld;
            prevHeld = held;
            curHeld = held;
            curPressed = (held & HELD_BITS) | (edge & ~HELD_BITS);
            keepNearHero1();
            runAs(hero2, bT);                   // atualiza o heroi 2
        } catch (Throwable t) {
            error("ak", t);
        }
    }

    /** A camera segue so o heroi 1: se o heroi 2 sair da tela, ele reaparece junto do heroi 1. */
    private static void keepNearHero1() throws Exception {
        int k1 = getInt(hero1, "K"), l1 = getInt(hero1, "L");
        int k2 = getInt(hero2, "K"), l2 = getInt(hero2, "L");
        if (Math.abs(k2 - k1) > 105 || Math.abs(l2 - l1) > 150) {
            setInt(hero2, "a", getInt(hero1, "a") + (16 << 8));
            setInt(hero2, "b", getInt(hero1, "b"));
            setInt(hero2, "K", k1 + 16);
            setInt(hero2, "L", l1);
            setInt(hero2, "G", 0);
            setInt(hero2, "H", 0);
        }
    }

    private static int getInt(Object o, String n) throws Exception {
        Field f = B.getDeclaredField(n);
        f.setAccessible(true);
        return f.getInt(o);
    }

    private static void setInt(Object o, String n, int v) throws Exception {
        Field f = B.getDeclaredField(n);
        f.setAccessible(true);
        f.setInt(o, v);
    }

    public static void ao() {
        if (failed || E == null) { callOriginalSafe(false); return; }
        callOriginal(eAo);                      // desenha a fase e o heroi 1
        if (hero2 == null || !active()) return;
        try {
            Object h = eBL.get(null);
            if (h == null || h != hero1) return;
            runAs(hero2, bV);                   // desenha o heroi 2 por cima
        } catch (Throwable t) {
            error("ao", t);
        }
    }

    private static void callOriginalSafe(boolean update) {
        try {
            init();
            callOriginal(update ? eAk : eAo);
        } catch (RuntimeException e) {
            throw e;
        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    // ---------------------------------------------------------------- heroi 2

    /** Roda "m" no heroi 2: troca e.bL e as teclas, executa e restaura. */
    private static void runAs(Object hero, Method m) throws Exception {
        Object oldBL = eBL.get(null);
        int[] saved = new int[allKeys.length];
        for (int i = 0; i < allKeys.length; i++) saved[i] = allKeys[i].getInt(null);
        try {
            eBL.set(null, hero);
            heldKeys[0].setInt(null, curHeld);        // df
            heldKeys[1].setInt(null, curPressed);     // di
            heldKeys[2].setInt(null, curPressed);     // dh
            try {
                m.invoke(hero);
            } catch (InvocationTargetException ite) {
                Throwable c = ite.getCause();
                throw c instanceof Exception ? (Exception) c : new RuntimeException(c);
            }
        } finally {
            eBL.set(null, oldBL);
            for (int i = 0; i < allKeys.length; i++) allKeys[i].setInt(null, saved[i]);
        }
    }

    private static Object cloneHero(Object src) throws Exception {
        Constructor<?> c = B.getDeclaredConstructor();
        c.setAccessible(true);
        Object n = c.newInstance();
        copyFields(B, src, n);
        // o heroi 2 nasce um pouco a frente do heroi 1
        shift(n, "K", 40);
        shift(n, "a", 40 << 8);
        return n;
    }

    private static void shift(Object o, String name, int dx) {
        try {
            Field f = B.getDeclaredField(name);
            f.setAccessible(true);
            f.setInt(o, f.getInt(o) + dx);
        } catch (Throwable t) {
            log("shift " + name + ": " + t);
        }
    }

    private static void copyFields(Class<?> k, Object src, Object dst) {
        for (Field f : k.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            try {
                f.setAccessible(true);
                Object v = f.get(src);
                f.set(dst, copyValue(v));
            } catch (Throwable t) {
                log("campo " + f.getName() + ": " + t);
            }
        }
    }

    private static Object copyValue(Object v) throws Exception {
        if (v == null) return null;
        Class<?> k = v.getClass();
        if (k.isArray()) {
            Class<?> ct = k.getComponentType();
            if (ct.isPrimitive() && !ct.isArray()) {
                int n = Array.getLength(v);
                Object r = Array.newInstance(ct, n);
                System.arraycopy(v, 0, r, 0, n);
                return r;
            }
            return v;          // arrays de objetos / multidimensionais: compartilhados (dados)
        }
        if (k == D) {          // o sprite guarda estado de animacao por heroi: precisa de copia propria
            Constructor<?> c = D.getDeclaredConstructor();
            c.setAccessible(true);
            Object n = c.newInstance();
            copyFields(D, v, n);
            return n;
        }
        return v;
    }

    private static void error(String where, Throwable t) {
        errors++;
        String msg = where + ": " + t;
        if (!msg.equals(lastErr)) { lastErr = msg; log(msg); android.util.Log.e("SOD", "hook", t); }
        status = "H2 erro " + msg;
        if (errors > 200) { failed = true; hero2 = null; status = "H2 desligado (muitos erros): " + msg; }
    }
}
