package com.nokia.mid.ui;

/** Subconjunto da API Nokia usado pelo jogo. */
public interface DirectGraphics {
    void setARGBColor(int argb);
}
