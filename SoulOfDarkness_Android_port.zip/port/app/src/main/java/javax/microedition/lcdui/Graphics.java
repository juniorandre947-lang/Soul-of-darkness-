package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;

/** Graphics do MIDP 2.0 em cima do android.graphics.Canvas (sem anti-alias nas formas). */
public class Graphics implements com.nokia.mid.ui.DirectGraphics {
    public static final int HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64;
    public static final int SOLID = 0, DOTTED = 1;

    private final android.graphics.Canvas cv;
    private final Paint paint = new Paint();      // cor/alpha das formas e texto
    private final Paint bmpPaint = new Paint();   // imagens: sempre opaco (alpha da cor nao vaza)
    private final Rect src = new Rect();
    private final Rect dst = new Rect();
    private final RectF oval = new RectF();
    private final Matrix mat = new Matrix();
    private final float[] mv = new float[9];
    private final Path path = new Path();
    private final int base;
    private Font font = Font.getDefaultFont();

    public Graphics(Bitmap bitmap) {
        cv = new android.graphics.Canvas(bitmap);
        paint.setAntiAlias(false);
        paint.setDither(false);
        paint.setFilterBitmap(false);
        bmpPaint.setAntiAlias(false);
        bmpPaint.setDither(false);
        bmpPaint.setFilterBitmap(false);
        base = cv.getSaveCount();
        cv.save();
        setColor(0);
    }

    // ---------------- estado ----------------
    public void resetClip() {
        cv.restoreToCount(base);
        cv.save();
    }

    public void setClip(int x, int y, int w, int h) {
        cv.restoreToCount(base);
        cv.save();
        cv.clipRect(x, y, x + Math.max(0, w), y + Math.max(0, h));
    }

    public void setColor(int rgb) { paint.setColor(0xFF000000 | rgb); }

    public void setColor(int r, int g, int b) {
        paint.setColor(0xFF000000 | ((r & 255) << 16) | ((g & 255) << 8) | (b & 255));
    }

    /** DirectGraphics (Nokia): cor com alpha. */
    public void setARGBColor(int argb) { paint.setColor(argb); }

    public void setFont(Font f) { font = f == null ? Font.getDefaultFont() : f; }
    public Font getFont() { return font; }

    // ---------------- formas ----------------
    public void fillRect(int x, int y, int w, int h) {
        if (w <= 0 || h <= 0) return;
        paint.setStyle(Paint.Style.FILL);
        cv.drawRect(x, y, x + w, y + h, paint);
    }

    public void drawRect(int x, int y, int w, int h) {
        if (w < 0 || h < 0) return;
        fillRect(x, y, w + 1, 1);
        if (h > 0) fillRect(x, y + h, w + 1, 1);
        if (h > 1) {
            fillRect(x, y + 1, 1, h - 1);
            if (w > 0) fillRect(x + w, y + 1, 1, h - 1);
        }
    }

    public void drawLine(int x1, int y1, int x2, int y2) {
        if (y1 == y2) { fillRect(Math.min(x1, x2), y1, Math.abs(x2 - x1) + 1, 1); return; }
        if (x1 == x2) { fillRect(x1, Math.min(y1, y2), 1, Math.abs(y2 - y1) + 1); return; }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0);
        cv.drawLine(x1 + 0.5f, y1 + 0.5f, x2 + 0.5f, y2 + 0.5f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    // MIDP: angulo 0 = 3h, positivo = anti-horario. Android: positivo = horario.
    public void drawArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        oval.set(x, y, x + w, y + h);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1);
        cv.drawArc(oval, -startAngle, -arcAngle, false, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    public void fillArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        oval.set(x, y, x + w, y + h);
        paint.setStyle(Paint.Style.FILL);
        cv.drawArc(oval, -startAngle, -arcAngle, true, paint);
    }

    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
        path.reset();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        paint.setStyle(Paint.Style.FILL);
        cv.drawPath(path, paint);
    }

    // ---------------- texto ----------------
    public void drawString(String s, int x, int y, int anchor) {
        if (s == null || s.length() == 0) return;
        font.apply(paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        float w = paint.measureText(s);
        Paint.FontMetrics fm = paint.getFontMetrics();
        float px = x;
        if ((anchor & HCENTER) != 0) px = x - w / 2f;
        else if ((anchor & RIGHT) != 0) px = x - w;
        float py;
        if ((anchor & BASELINE) != 0) py = y;
        else if ((anchor & BOTTOM) != 0) py = y - fm.descent;
        else py = y - fm.ascent;
        cv.drawText(s, px, py, paint);
        paint.setAntiAlias(false);
    }

    // ---------------- imagens ----------------
    public void drawImage(Image img, int x, int y, int anchor) {
        int w = img.getWidth(), h = img.getHeight();
        int px = x, py = y;
        if ((anchor & HCENTER) != 0) px = x - w / 2;
        else if ((anchor & RIGHT) != 0) px = x - w;
        if ((anchor & VCENTER) != 0) py = y - h / 2;
        else if ((anchor & BOTTOM) != 0) py = y - h;
        cv.drawBitmap(img.bmp, px, py, bmpPaint);
    }

    public void drawRegion(Image img, int xs, int ys, int w, int h, int t, int xd, int yd, int anchor) {
        if (w <= 0 || h <= 0) return;
        boolean swap = t >= 4;
        int dw = swap ? h : w, dh = swap ? w : h;
        int px = xd, py = yd;
        if ((anchor & HCENTER) != 0) px = xd - dw / 2;
        else if ((anchor & RIGHT) != 0) px = xd - dw;
        if ((anchor & VCENTER) != 0) py = yd - dh / 2;
        else if ((anchor & BOTTOM) != 0) py = yd - dh;

        src.set(xs, ys, xs + w, ys + h);
        if (t == 0) {
            dst.set(px, py, px + w, py + h);
            cv.drawBitmap(img.bmp, src, dst, bmpPaint);
            return;
        }
        float fw = w, fh = h;
        switch (t) {
            case 1: set(1, 0, 0, 0, -1, fh); break;          // MIRROR_ROT180 (espelho vertical)
            case 2: set(-1, 0, fw, 0, 1, 0); break;          // MIRROR (espelho horizontal)
            case 3: set(-1, 0, fw, 0, -1, fh); break;        // ROT180
            case 4: set(0, 1, 0, 1, 0, 0); break;           // MIRROR_ROT270
            case 5: set(0, -1, fh, 1, 0, 0); break;         // ROT90 (horario)
            case 6: set(0, 1, 0, -1, 0, fw); break;         // ROT270
            case 7: set(0, -1, fh, -1, 0, fw); break;       // MIRROR_ROT90
            default: set(1, 0, 0, 0, 1, 0); break;
        }
        cv.save();
        cv.translate(px, py);
        cv.concat(mat);
        dst.set(0, 0, w, h);
        cv.drawBitmap(img.bmp, src, dst, bmpPaint);
        cv.restore();
    }

    private void set(float a, float b, float tx, float c, float d, float ty) {
        mv[0] = a; mv[1] = b; mv[2] = tx;
        mv[3] = c; mv[4] = d; mv[5] = ty;
        mv[6] = 0; mv[7] = 0; mv[8] = 1;
        mat.setValues(mv);
    }

    @SuppressWarnings("deprecation")
    public void drawRGB(int[] rgb, int offset, int scanlength, int x, int y, int w, int h, boolean processAlpha) {
        if (w <= 0 || h <= 0) return;
        cv.drawBitmap(rgb, offset, scanlength, x, y, w, h, processAlpha, null);
    }
}
