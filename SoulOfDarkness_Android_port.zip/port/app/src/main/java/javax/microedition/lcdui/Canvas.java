package javax.microedition.lcdui;

public abstract class Canvas extends Displayable {
    protected Canvas() { }

    protected abstract void paint(Graphics g);
    protected void keyPressed(int keyCode) { }
    protected void keyReleased(int keyCode) { }
    protected void keyRepeated(int keyCode) { }
    protected void showNotify() { }
    protected void hideNotify() { }

    public int getWidth() { return Display.WIDTH; }
    public int getHeight() { return Display.HEIGHT; }
    public boolean isDoubleBuffered() { return true; }

    /** Pinta de forma sincrona na thread que chamou (como serviceRepaints). */
    public void repaint() {
        Display.Host h = Display.host;
        if (h != null) h.repaint(this);
    }
    public final void serviceRepaints() { }

    // ---- despacho a partir da camada Android ----
    public final void __paint(Graphics g) { paint(g); }
    public final void __keyPressed(int k) { keyPressed(k); }
    public final void __keyReleased(int k) { keyReleased(k); }
    public final void __showNotify() { showNotify(); }
    public final void __hideNotify() { hideNotify(); }
}
