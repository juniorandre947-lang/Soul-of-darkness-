package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.IOException;
import java.io.InputStream;

public class Image {
    final Bitmap bmp;
    private final boolean mutable;

    private Image(Bitmap b, boolean mutable) { this.bmp = b; this.mutable = mutable; }

    public static Image createImage(int w, int h) {
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        b.eraseColor(0xFFFFFFFF); // MIDP: imagem mutavel nasce branca
        return new Image(b, true);
    }

    public static Image createImage(String name) throws IOException {
        InputStream in = Image.class.getResourceAsStream(name);
        if (in == null) throw new IOException("recurso nao encontrado: " + name);
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            byte[] d = bo.toByteArray();
            return createImage(d, 0, d.length);
        } finally {
            in.close();
        }
    }

    public static Image createImage(byte[] data, int off, int len) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap b = BitmapFactory.decodeByteArray(data, off, len, o);
        if (b == null) throw new IllegalArgumentException("imagem invalida");
        return new Image(b, false);
    }

    public static Image createRGBImage(int[] rgb, int w, int h, boolean processAlpha) {
        int[] px = rgb;
        if (!processAlpha) {
            px = new int[w * h];
            for (int i = 0; i < px.length; i++) px[i] = rgb[i] | 0xFF000000;
        }
        Bitmap b = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
        return new Image(b, false);
    }

    public Graphics getGraphics() {
        if (!mutable) throw new IllegalStateException("imagem imutavel");
        return new Graphics(bmp);
    }

    public int getWidth() { return bmp.getWidth(); }
    public int getHeight() { return bmp.getHeight(); }
    public boolean isMutable() { return mutable; }

    public void getRGB(int[] out, int offset, int scanlength, int x, int y, int w, int h) {
        bmp.getPixels(out, offset, scanlength, x, y, w, h);
    }
}
