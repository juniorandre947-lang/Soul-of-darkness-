package javax.microedition.lcdui;

public abstract class Displayable {
    private CommandListener listener;
    public void addCommand(Command c) { }
    public void removeCommand(Command c) { }
    public void setCommandListener(CommandListener l) { listener = l; }
    public CommandListener getCommandListener() { return listener; }
}
