import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.Opcodes;
import jdk.internal.org.objectweb.asm.tree.*;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Altera e.ak() do jogo: cada "inimigo.t()" (atualizacao de entidade, exceto o heroi 1) passa a ser
 *     DUP; Hook.pre(Object); invokevirtual b.t(); Hook.post();
 * assim o Hook escolhe, por inimigo, qual heroi (1 ou 2) e o alvo (e.bL) durante a atualizacao dele.
 * Uso: PatchJar entrada.jar saida.jar
 */
public class PatchJar {
    public static void main(String[] a) throws Exception {
        ZipFile in = new ZipFile(a[0]);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]));
        Enumeration<? extends ZipEntry> en = in.entries();
        int patched = 0;
        while (en.hasMoreElements()) {
            ZipEntry ze = en.nextElement();
            byte[] data = in.getInputStream(ze).readAllBytes();
            if (ze.getName().equals("e.class")) {
                ClassReader cr = new ClassReader(data);
                ClassNode cn = new ClassNode();
                cr.accept(cn, 0);
                for (MethodNode m : cn.methods) {
                    if (!m.name.equals("ak") || !m.desc.equals("()V")) continue;
                    List<MethodInsnNode> sites = new ArrayList<>();
                    for (AbstractInsnNode i = m.instructions.getFirst(); i != null; i = i.getNext()) {
                        if (i.getOpcode() != Opcodes.INVOKEVIRTUAL) continue;
                        MethodInsnNode mi = (MethodInsnNode) i;
                        if (!mi.owner.equals("b") || !mi.name.equals("t") || !mi.desc.equals("()V")) continue;
                        AbstractInsnNode p = mi.getPrevious();
                        while (p != null && p.getOpcode() < 0) p = p.getPrevious();   // pula labels/linhas
                        if (p instanceof FieldInsnNode) {
                            FieldInsnNode f = (FieldInsnNode) p;
                            if (f.getOpcode() == Opcodes.GETSTATIC && f.name.equals("bL")) continue; // heroi 1: nao mexe
                        }
                        sites.add(mi);
                    }
                    for (MethodInsnNode mi : sites) {
                        InsnList pre = new InsnList();
                        pre.add(new InsnNode(Opcodes.DUP));
                        pre.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/sod/port/Hook", "pre", "(Ljava/lang/Object;)V", false));
                        m.instructions.insertBefore(mi, pre);
                        m.instructions.insert(mi, new MethodInsnNode(Opcodes.INVOKESTATIC, "com/sod/port/Hook", "post", "()V", false));
                        patched++;
                    }
                }
                ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
                cn.accept(cw);
                data = cw.toByteArray();
            }
            ZipEntry ne = new ZipEntry(ze.getName());
            ne.setTime(ze.getTime());
            out.putNextEntry(ne);
            out.write(data);
            out.closeEntry();
        }
        out.close();
        in.close();
        System.out.println("pontos alterados em e.ak(): " + patched);
    }
}
