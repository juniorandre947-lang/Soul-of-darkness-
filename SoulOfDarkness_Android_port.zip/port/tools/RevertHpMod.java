import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.tree.*;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Desfaz o MOD "vida dos inimigos em dobro" do game.jar.
 * O MOD criou em b.class o metodo zzHP(I)I = C(I) * 2 e trocou, em 15 pontos, as chamadas
 *     inimigo.as = this.C(0)      por      inimigo.as = this.zzHP(0)
 * (b.as = vida do inimigo). Aqui cada chamada volta a ser b.C(I)I e o metodo zzHP e removido.
 * Uso: java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED \
 *           --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED \
 *           RevertHpMod.java entrada.jar saida.jar
 */
public class RevertHpMod {
    public static void main(String[] a) throws Exception {
        ZipFile in = new ZipFile(a[0]);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]));
        int replaced = 0, removed = 0;
        Enumeration<? extends ZipEntry> en = in.entries();
        while (en.hasMoreElements()) {
            ZipEntry ze = en.nextElement();
            byte[] data = in.getInputStream(ze).readAllBytes();
            if (ze.getName().equals("b.class")) {
                ClassNode cn = new ClassNode();
                new ClassReader(data).accept(cn, 0);
                for (MethodNode m : cn.methods) {
                    for (AbstractInsnNode i = m.instructions.getFirst(); i != null; i = i.getNext()) {
                        if (!(i instanceof MethodInsnNode)) continue;
                        MethodInsnNode mi = (MethodInsnNode) i;
                        if (mi.owner.equals("b") && mi.name.equals("zzHP") && mi.desc.equals("(I)I")) {
                            mi.name = "C";
                            replaced++;
                        }
                    }
                }
                Iterator<MethodNode> it = cn.methods.iterator();
                while (it.hasNext()) {
                    MethodNode m = it.next();
                    if (m.name.equals("zzHP") && m.desc.equals("(I)I")) { it.remove(); removed++; }
                }
                ClassWriter cw = new ClassWriter(0);    // nada muda na pilha nem nos frames: copia como esta
                cn.accept(cw);
                data = cw.toByteArray();
            }
            ZipEntry ne = new ZipEntry(ze.getName());
            ne.setTime(ze.getTime());
            out.putNextEntry(ne);
            out.write(data);
            out.closeEntry();
        }
        out.close();
        in.close();
        System.out.println("chamadas zzHP -> C: " + replaced + " | metodo zzHP removido: " + removed);
    }
}
