#!/usr/bin/env python3
"""
Gera o pacote HD do Soul of Darkness a partir dos PNGs que o app gravou (files/dump/).

Uso:
  python upscale_hd.py DUMP_DIR HD_DIR [--esrgan CAMINHO/realesrgan-ncnn-vulkan] [--scale 4]

  DUMP_DIR  pasta 'dump' copiada do celular (Android/data/com.sod.port/files/dump)
  HD_DIR    pasta de saida; copie o conteudo para Android/data/com.sod.port/files/hd/
            (ou para app/src/main/assets/hd/ e gere o APK de novo)

Regras (as mesmas do ampliador embutido no app, ver Upscale.java):
  - sprites / HUD / imagens pequenas (tem transparencia ou lado <= 64): pixel art (EPX x2, repetido).
  - fundos, tilesets, retratos sem transparencia: filtro anti-quadriculado (dithering) + IA (Real-ESRGAN ncnn) se --esrgan for dado,
    senao bicubico. A IA e opcional, mas e onde o ganho de qualidade aparece.
O nome do arquivo (CRC32 do PNG original) e mantido: e a chave que o app usa para achar a versao HD.
Requer: pip install pillow numpy
"""
import argparse, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image


def looks_like_sprite(a):
    h, w = a.shape[:2]
    if max(w, h) <= 64:
        return True
    return (a[..., 3] < 128).sum() * 50 > a.shape[0] * a.shape[1]


def epx(p):
    h, w = p.shape
    A = np.vstack([p[:1], p[:-1]])       # cima
    D = np.vstack([p[1:], p[-1:]])       # baixo
    C = np.hstack([p[:, :1], p[:, :-1]]) # esquerda
    B = np.hstack([p[:, 1:], p[:, -1:]]) # direita
    P = p
    o = np.empty((h * 2, w * 2), dtype=p.dtype)
    o[0::2, 0::2] = np.where((C == A) & (C != D) & (A != B), A, P)
    o[0::2, 1::2] = np.where((A == B) & (A != C) & (B != D), B, P)
    o[1::2, 0::2] = np.where((D == C) & (D != B) & (C != A), C, P)
    o[1::2, 1::2] = np.where((B == D) & (B != A) & (D != C), D, P)
    return o


def dedither(img, thr=96):
    """Tira o quadriculado dos fundos (filtro bilateral 3x3; mesmo algoritmo de Upscale.dedither)."""
    a = np.array(img.convert("RGBA")).astype(np.float32)
    rgb, al = a[..., :3], a[..., 3]
    h, w = al.shape
    opaque = al == 255
    pad = np.pad(rgb, ((1, 1), (1, 1), (0, 0)), mode="edge")
    pop = np.pad(opaque, ((1, 1), (1, 1)), constant_values=False)
    sw = np.full((h, w), 2.0, dtype=np.float32)
    acc = 2.0 * rgb
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            n = pad[1 + dy:1 + dy + h, 1 + dx:1 + dx + w]
            no = pop[1 + dy:1 + dy + h, 1 + dx:1 + dx + w]
            d = np.abs(n - rgb).sum(axis=2)
            k = np.where((d < thr) & no, 1.0 - d / thr, 0.0).astype(np.float32)
            sw += k
            acc += k[..., None] * n
    out = a.copy()
    out[..., :3] = np.where(opaque[..., None], acc / sw[..., None], rgb)
    return Image.fromarray(np.clip(out.round(), 0, 255).astype(np.uint8), "RGBA")


def pixel_art(img, scale):
    a = np.array(img.convert("RGBA"))
    a[a[..., 3] == 0] = 0                                  # toda transparencia igual
    packed = a.view(np.uint32).reshape(a.shape[:2])        # 1 inteiro por pixel
    s = 1
    while s < scale:
        packed = epx(packed); s *= 2
    out = np.ascontiguousarray(packed).view(np.uint8).reshape(packed.shape[0], packed.shape[1], 4)
    return Image.fromarray(out, "RGBA")


def premult_resize(img, scale, method):
    a = np.array(img.convert("RGBA")).astype(np.float32)
    al = a[..., 3:4] / 255.0
    pm = np.concatenate([a[..., :3] * al, a[..., 3:4]], axis=2)
    ch = [Image.fromarray(pm[..., i], "F").resize((img.width * scale, img.height * scale), method) for i in range(4)]
    r = np.stack([np.array(c) for c in ch], axis=2)
    al2 = np.clip(r[..., 3:4], 0, 255) / 255.0
    rgb = np.where(al2 > 0.002, r[..., :3] / np.maximum(al2, 0.002), 0)
    out = np.concatenate([np.clip(rgb, 0, 255), np.clip(r[..., 3:4], 0, 255)], axis=2).round().astype(np.uint8)
    return Image.fromarray(out, "RGBA")


def esrgan(img, exe, scale):
    """IA no RGB (4x) e Lanczos no alpha. Para scale 2/8, redimensiona o resultado."""
    with tempfile.TemporaryDirectory() as td:
        src, dst = os.path.join(td, "i.png"), os.path.join(td, "o.png")
        img.convert("RGB").save(src)
        subprocess.run([exe, "-i", src, "-o", dst, "-n", "realesrgan-x4plus-anime", "-s", "4"],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        rgb = Image.open(dst).convert("RGB")
    size = (img.width * scale, img.height * scale)
    if rgb.size != size:
        rgb = rgb.resize(size, Image.LANCZOS)
    alpha = img.convert("RGBA").getchannel("A").resize(size, Image.BICUBIC)
    rgb.putalpha(alpha)
    return rgb


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dump"); ap.add_argument("hd")
    ap.add_argument("--esrgan"); ap.add_argument("--scale", type=int, default=4)
    ar = ap.parse_args()
    if ar.scale not in (2, 4, 8):
        sys.exit("--scale deve ser 2, 4 ou 8 (e igual a HdPack.SCALE no app)")
    os.makedirs(ar.hd, exist_ok=True)
    files = sorted(f for f in os.listdir(ar.dump) if f.lower().endswith(".png"))
    for i, f in enumerate(files, 1):
        out_path = os.path.join(ar.hd, f)
        if os.path.exists(out_path):
            continue
        img = Image.open(os.path.join(ar.dump, f)).convert("RGBA")
        a = np.array(img)
        if looks_like_sprite(a):
            out, how = pixel_art(img, ar.scale), "pixel"
        elif ar.esrgan:
            out, how = esrgan(dedither(img), ar.esrgan, ar.scale), "IA"
        else:
            out, how = premult_resize(dedither(img), ar.scale, Image.BICUBIC), "bicubico"
        out.save(out_path)
        print(f"[{i}/{len(files)}] {f} {img.width}x{img.height} -> {out.width}x{out.height} ({how})")


if __name__ == "__main__":
    main()
