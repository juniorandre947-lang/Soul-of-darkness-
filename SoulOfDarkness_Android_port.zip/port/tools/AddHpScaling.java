import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.Opcodes;
import jdk.internal.org.objectweb.asm.tree.*;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * MOD "vida dos inimigos dobra a cada fase".
 *
 * Em b.class a vida do inimigo e definida em 15 pontos por   this.as = this.C(0)   (C(I) le a tabela e.cv).
 * Este patch cria o metodo  b.zzHP(I)I = C(I) << min(max(b.ch, 0), MAX_SHIFT)   e troca essas 15 chamadas
 * por zzHP. b.ch = indice da fase atual (0 = primeira fase), entao:
 *     fase 1 -> x1 | fase 2 -> x2 | fase 3 -> x4 | fase 4 -> x8 | ...  (vida original * 2^(fase-1))
 * Os outros usos de C(I) (ex.: fx = C(2), contagens de particulas) NAO sao alterados.
 *
 * Uso: java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED \
 *           --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED \
 *           AddHpScaling.java entrada.jar saida.jar [MAX_SHIFT]
 */
public class AddHpScaling {
    public static void main(String[] a) throws Exception {
        int maxShift = a.length > 2 ? Integer.parseInt(a[2]) : 14;   // limite do multiplicador: 2^14 = 16384x
        ZipFile in = new ZipFile(a[0]);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]));
        int replaced = 0;
        Enumeration<? extends ZipEntry> en = in.entries();
        while (en.hasMoreElements()) {
            ZipEntry ze = en.nextElement();
            byte[] data = in.getInputStream(ze).readAllBytes();
            if (ze.getName().equals("b.class")) {
                ClassNode cn = new ClassNode();
                new ClassReader(data).accept(cn, 0);
                for (MethodNode m : cn.methods) {
                    if (m.name.equals("zzHP")) throw new IllegalStateException("zzHP ja existe no jar");
                    for (AbstractInsnNode i = m.instructions.getFirst(); i != null; i = i.getNext()) {
                        if (!(i instanceof MethodInsnNode)) continue;
                        MethodInsnNode mi = (MethodInsnNode) i;
                        if (!mi.owner.equals("b") || !mi.name.equals("C") || !mi.desc.equals("(I)I")) continue;
                        AbstractInsnNode n = mi.getNext();
                        while (n != null && n.getOpcode() < 0) n = n.getNext();
                        if (n instanceof FieldInsnNode && n.getOpcode() == Opcodes.PUTFIELD
                                && ((FieldInsnNode) n).owner.equals("b") && ((FieldInsnNode) n).name.equals("as")) {
                            mi.name = "zzHP";
                            replaced++;
                        }
                    }
                }
                MethodNode hp = new MethodNode(Opcodes.ACC_PRIVATE, "zzHP", "(I)I", null, null);
                InsnList il = hp.instructions;
                il.add(new VarInsnNode(Opcodes.ALOAD, 0));
                il.add(new VarInsnNode(Opcodes.ILOAD, 1));
                il.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, "b", "C", "(I)I", false));
                il.add(new FieldInsnNode(Opcodes.GETSTATIC, "b", "ch", "I"));
                il.add(new InsnNode(Opcodes.ICONST_0));
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Math", "max", "(II)I", false));
                il.add(new IntInsnNode(Opcodes.BIPUSH, maxShift));
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Math", "min", "(II)I", false));
                il.add(new InsnNode(Opcodes.ISHL));
                il.add(new InsnNode(Opcodes.IRETURN));
                hp.maxStack = 3;
                hp.maxLocals = 2;
                cn.methods.add(hp);
                ClassWriter cw = new ClassWriter(0);
                cn.accept(cw);
                data = cw.toByteArray();
            }
            ZipEntry ne = new ZipEntry(ze.getName());
            ne.setTime(ze.getTime());
            out.putNextEntry(ne);
            out.write(data);
            out.closeEntry();
        }
        out.close();
        in.close();
        System.out.println("chamadas C -> zzHP (b.as): " + replaced + " | MAX_SHIFT=" + maxShift);
        if (replaced != 15) { System.err.println("ATENCAO: esperado 15 pontos"); System.exit(1); }
    }
}
